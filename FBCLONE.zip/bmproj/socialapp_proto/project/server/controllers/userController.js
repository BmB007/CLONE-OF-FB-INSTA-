import User from '../models/userModel.js';
import generateToken from '../utils/generateToken.js';

// @desc    Auth user & get token
// @route   POST /api/users/login
// @access  Public
export const authUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email }).maxTimeMS(20000); // Add timeout of 20s

    if (user && (await user.matchPassword(password))) {
      res.json({
        _id: user._id,
        username: user.username,
        email: user.email,
        profilePicture: user.profilePicture,
        bio: user.bio,
        isPrivate: user.isPrivate,
        isAdmin: user.isAdmin,
        token: generateToken(user._id),
      });
    } else {
      res.status(401);
      throw new Error('Invalid email or password');
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Register a new user
// @route   POST /api/users
// @access  Public
export const registerUser = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    const userExists = await User.findOne({ 
      $or: [{ email }, { username }] 
    }).maxTimeMS(20000); // Add timeout of 20s

    if (userExists) {
      res.status(400);
      throw new Error('User already exists');
    }

    const user = await User.create({
      username,
      email,
      password,
    });

    if (user) {
      res.status(201).json({
        _id: user._id,
        username: user.username,
        email: user.email,
        profilePicture: user.profilePicture,
        bio: user.bio,
        isPrivate: user.isPrivate,
        isAdmin: user.isAdmin,
        token: generateToken(user._id),
      });
    } else {
      res.status(400);
      throw new Error('Invalid user data');
    }
  } catch (error) {
    // Improved error handling
    const message = error.code === 11000 
      ? 'Username or email already exists'
      : error.message;
    res.status(400).json({ message });
  }
};

// @desc    Get user profile
// @route   GET /api/users/profile
// @access  Private
export const getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('-password')
      .populate('posts')
      .maxTimeMS(20000); // Add timeout of 20s

    if (user) {
      res.json(user);
    } else {
      res.status(404);
      throw new Error('User not found');
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Update user profile
// @route   PUT /api/users/profile
// @access  Private
export const updateUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).maxTimeMS(20000); // Add timeout of 20s

    if (user) {
      user.username = req.body.username || user.username;
      user.email = req.body.email || user.email;
      user.profilePicture = req.body.profilePicture || user.profilePicture;
      user.bio = req.body.bio || user.bio;
      user.isPrivate = req.body.isPrivate !== undefined ? req.body.isPrivate : user.isPrivate;

      if (req.body.password) {
        user.password = req.body.password;
      }

      const updatedUser = await user.save();

      res.json({
        _id: updatedUser._id,
        username: updatedUser.username,
        email: updatedUser.email,
        profilePicture: updatedUser.profilePicture,
        bio: updatedUser.bio,
        isPrivate: updatedUser.isPrivate,
        isAdmin: updatedUser.isAdmin,
        token: generateToken(updatedUser._id),
      });
    } else {
      res.status(404);
      throw new Error('User not found');
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Get user by ID
// @route   GET /api/users/:id
// @access  Private
export const getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password')
      .populate({
        path: 'posts',
        options: { sort: { createdAt: -1 } },
      })
      .maxTimeMS(20000); // Add timeout of 20s

    if (user) {
      if (user.isPrivate && 
          !user.followers.includes(req.user._id) && 
          user._id.toString() !== req.user._id.toString()) {
        const limitedUser = {
          _id: user._id,
          username: user.username,
          profilePicture: user.profilePicture,
          bio: user.bio,
          isPrivate: user.isPrivate,
          followers: user.followers.length,
          following: user.following.length,
          isFollowing: user.followers.includes(req.user._id),
          isPendingRequest: user.pendingFollowRequests.includes(req.user._id),
        };
        res.json(limitedUser);
      } else {
        const fullUser = {
          _id: user._id,
          username: user.username,
          profilePicture: user.profilePicture,
          bio: user.bio,
          isPrivate: user.isPrivate,
          posts: user.posts,
          followers: user.followers,
          following: user.following,
          pendingFollowRequests: user.pendingFollowRequests,
          isFollowing: user.followers.includes(req.user._id),
          isPendingRequest: user.pendingFollowRequests.includes(req.user._id),
        };
        res.json(fullUser);
      }
    } else {
      res.status(404);
      throw new Error('User not found');
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Follow user
// @route   POST /api/users/:id/follow
// @access  Private
export const followUser = async (req, res) => {
  try {
    if (req.user._id.toString() === req.params.id) {
      res.status(400);
      throw new Error('You cannot follow yourself');
    }

    const userToFollow = await User.findById(req.params.id).maxTimeMS(20000);
    const currentUser = await User.findById(req.user._id).maxTimeMS(20000);

    if (!userToFollow) {
      res.status(404);
      throw new Error('User not found');
    }

    if (userToFollow.followers.includes(req.user._id)) {
      res.status(400);
      throw new Error('Already following this user');
    }

    if (userToFollow.pendingFollowRequests.includes(req.user._id)) {
      res.status(400);
      throw new Error('Follow request already sent');
    }

    if (userToFollow.isPrivate) {
      userToFollow.pendingFollowRequests.push(req.user._id);
      await userToFollow.save();
      res.status(200).json({ message: 'Follow request sent' });
    } else {
      userToFollow.followers.push(req.user._id);
      currentUser.following.push(userToFollow._id);
      
      await userToFollow.save();
      await currentUser.save();
      
      res.status(200).json({ message: 'User followed successfully' });
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Unfollow user
// @route   POST /api/users/:id/unfollow
// @access  Private
export const unfollowUser = async (req, res) => {
  try {
    if (req.user._id.toString() === req.params.id) {
      res.status(400);
      throw new Error('You cannot unfollow yourself');
    }

    const userToUnfollow = await User.findById(req.params.id).maxTimeMS(20000);
    const currentUser = await User.findById(req.user._id).maxTimeMS(20000);

    if (!userToUnfollow) {
      res.status(404);
      throw new Error('User not found');
    }

    userToUnfollow.followers = userToUnfollow.followers.filter(
      (follower) => follower.toString() !== req.user._id.toString()
    );

    currentUser.following = currentUser.following.filter(
      (following) => following.toString() !== req.params.id.toString()
    );

    await userToUnfollow.save();
    await currentUser.save();

    res.status(200).json({ message: 'User unfollowed successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Accept follow request
// @route   POST /api/users/:id/accept-follow
// @access  Private
export const acceptFollowRequest = async (req, res) => {
  try {
    const followerUser = await User.findById(req.params.id).maxTimeMS(20000);
    const currentUser = await User.findById(req.user._id).maxTimeMS(20000);

    if (!followerUser) {
      res.status(404);
      throw new Error('User not found');
    }

    if (!currentUser.pendingFollowRequests.includes(req.params.id)) {
      res.status(400);
      throw new Error('No pending follow request from this user');
    }

    currentUser.pendingFollowRequests = currentUser.pendingFollowRequests.filter(
      (request) => request.toString() !== req.params.id.toString()
    );

    currentUser.followers.push(req.params.id);
    followerUser.following.push(req.user._id);

    await currentUser.save();
    await followerUser.save();

    res.status(200).json({ message: 'Follow request accepted' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Reject follow request
// @route   POST /api/users/:id/reject-follow
// @access  Private
export const rejectFollowRequest = async (req, res) => {
  try {
    const currentUser = await User.findById(req.user._id).maxTimeMS(20000);

    if (!currentUser.pendingFollowRequests.includes(req.params.id)) {
      res.status(400);
      throw new Error('No pending follow request from this user');
    }

    currentUser.pendingFollowRequests = currentUser.pendingFollowRequests.filter(
      (request) => request.toString() !== req.params.id.toString()
    );

    await currentUser.save();

    res.status(200).json({ message: 'Follow request rejected' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Search users
// @route   GET /api/users/search
// @access  Private
export const searchUsers = async (req, res) => {
  try {
    const { query } = req.query;
    
    if (!query) {
      return res.status(400).json({ message: 'Search query is required' });
    }

    const users = await User.find({
      username: { $regex: query, $options: 'i' },
      _id: { $ne: req.user._id },
    })
      .select('username profilePicture isPrivate')
      .maxTimeMS(20000); // Add timeout of 20s

    res.json(users);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};