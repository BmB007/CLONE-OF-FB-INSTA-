import Post from '../models/postModel.js';
import User from '../models/userModel.js';

// @desc    Create a new post
// @route   POST /api/posts
// @access  Private
export const createPost = async (req, res) => {
  try {
    const { caption, image } = req.body;

    if (!image) {
      res.status(400);
      throw new Error('Please upload an image');
    }

    const post = new Post({
      caption,
      image,
      user: req.user._id,
    });

    const createdPost = await post.save();

    // Add post to user's posts array
    await User.findByIdAndUpdate(req.user._id, {
      $push: { posts: createdPost._id },
    });

    // Populate user data in the response
    const populatedPost = await Post.findById(createdPost._id).populate('user', 'username profilePicture');

    res.status(201).json(populatedPost);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Get all posts from followed users (feed)
// @route   GET /api/posts/feed
// @access  Private
export const getFeedPosts = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    // Get all users the current user is following
    const following = user.following;

    // Add the current user to see their own posts
    following.push(req.user._id);

    // Get a list of users with private accounts that the user doesn't follow
    const privateUsers = await User.find({
      isPrivate: true,
      _id: { $nin: following },
    }).select('_id');

    const privateUserIds = privateUsers.map(user => user._id);

    // Find posts from followed users and exclude private users not followed
    const posts = await Post.find({
      user: { $in: following, $nin: privateUserIds },
    })
      .sort({ createdAt: -1 })
      .populate('user', 'username profilePicture')
      .populate({
        path: 'comments.user',
        select: 'username profilePicture',
      });

    res.json(posts);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Get post by ID
// @route   GET /api/posts/:id
// @access  Private
export const getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)
      .populate('user', 'username profilePicture isPrivate')
      .populate({
        path: 'comments.user',
        select: 'username profilePicture',
      });

    if (post) {
      // Check if post belongs to private user and if user is authorized to view
      if (
        post.user.isPrivate &&
        post.user._id.toString() !== req.user._id.toString()
      ) {
        const user = await User.findById(post.user._id);
        if (!user.followers.includes(req.user._id)) {
          res.status(403);
          throw new Error('Not authorized to view this post');
        }
      }

      res.json(post);
    } else {
      res.status(404);
      throw new Error('Post not found');
    }
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Like/unlike a post
// @route   PUT /api/posts/:id/like
// @access  Private
export const likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      res.status(404);
      throw new Error('Post not found');
    }

    // Check if post belongs to private user and if user is authorized to view
    const postUser = await User.findById(post.user);
    
    if (
      postUser.isPrivate &&
      postUser._id.toString() !== req.user._id.toString() &&
      !postUser.followers.includes(req.user._id)
    ) {
      res.status(403);
      throw new Error('Not authorized to interact with this post');
    }

    const isLiked = post.likes.includes(req.user._id);

    if (isLiked) {
      // Unlike the post
      post.likes = post.likes.filter(
        (like) => like.toString() !== req.user._id.toString()
      );
    } else {
      // Like the post
      post.likes.push(req.user._id);
    }

    await post.save();

    res.json({ likes: post.likes, message: isLiked ? 'Post unliked' : 'Post liked' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Comment on a post
// @route   POST /api/posts/:id/comment
// @access  Private
export const addComment = async (req, res) => {
  try {
    const { text } = req.body;

    if (!text) {
      res.status(400);
      throw new Error('Comment text is required');
    }

    const post = await Post.findById(req.params.id);

    if (!post) {
      res.status(404);
      throw new Error('Post not found');
    }

    // Check if post belongs to private user and if user is authorized to interact
    const postUser = await User.findById(post.user);
    
    if (
      postUser.isPrivate &&
      postUser._id.toString() !== req.user._id.toString() &&
      !postUser.followers.includes(req.user._id)
    ) {
      res.status(403);
      throw new Error('Not authorized to interact with this post');
    }

    const comment = {
      text,
      user: req.user._id,
    };

    post.comments.push(comment);
    await post.save();

    // Return the updated post with populated user data
    const updatedPost = await Post.findById(req.params.id)
      .populate('user', 'username profilePicture')
      .populate({
        path: 'comments.user',
        select: 'username profilePicture',
      });

    res.status(201).json(updatedPost);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Delete a post
// @route   DELETE /api/posts/:id
// @access  Private
export const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      res.status(404);
      throw new Error('Post not found');
    }

    // Check if user is authorized to delete the post
    if (post.user.toString() !== req.user._id.toString() && !req.user.isAdmin) {
      res.status(403);
      throw new Error('Not authorized to delete this post');
    }

    // Remove post from user's posts array
    await User.findByIdAndUpdate(post.user, {
      $pull: { posts: post._id },
    });

    await Post.deleteOne({ _id: post._id });

    res.json({ message: 'Post deleted' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// @desc    Delete a comment
// @route   DELETE /api/posts/:id/comments/:commentId
// @access  Private
export const deleteComment = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) {
      res.status(404);
      throw new Error('Post not found');
    }

    const comment = post.comments.find(
      (c) => c._id.toString() === req.params.commentId
    );

    if (!comment) {
      res.status(404);
      throw new Error('Comment not found');
    }

    // Check if user is authorized to delete the comment
    if (
      comment.user.toString() !== req.user._id.toString() &&
      post.user.toString() !== req.user._id.toString() &&
      !req.user.isAdmin
    ) {
      res.status(403);
      throw new Error('Not authorized to delete this comment');
    }

    // Remove comment
    post.comments = post.comments.filter(
      (c) => c._id.toString() !== req.params.commentId
    );

    await post.save();

    // Return the updated post with populated user data
    const updatedPost = await Post.findById(req.params.id)
      .populate('user', 'username profilePicture')
      .populate({
        path: 'comments.user',
        select: 'username profilePicture',
      });

    res.json(updatedPost);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};