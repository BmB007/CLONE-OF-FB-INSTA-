import express from 'express';
import {
  createPost,
  getFeedPosts,
  getPostById,
  likePost,
  addComment,
  deletePost,
  deleteComment,
} from '../controllers/postController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/')
  .post(protect, createPost);

router.route('/feed')
  .get(protect, getFeedPosts);

router.route('/:id')
  .get(protect, getPostById)
  .delete(protect, deletePost);

router.route('/:id/like')
  .put(protect, likePost);

router.route('/:id/comment')
  .post(protect, addComment);

router.route('/:id/comments/:commentId')
  .delete(protect, deleteComment);

export default router;