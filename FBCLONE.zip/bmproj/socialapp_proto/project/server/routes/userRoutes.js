import express from 'express';
import { 
  authUser,
  registerUser,
  getUserProfile,
  updateUserProfile,
  getUserById,
  followUser,
  unfollowUser,
  acceptFollowRequest,
  rejectFollowRequest,
  searchUsers
} from '../controllers/userController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/').post(registerUser);
router.post('/login', authUser);
router.get('/search', protect, searchUsers);
router
  .route('/profile')
  .get(protect, getUserProfile)
  .put(protect, updateUserProfile);
router.route('/:id').get(protect, getUserById);
router.route('/:id/follow').post(protect, followUser);
router.route('/:id/unfollow').post(protect, unfollowUser);
router.route('/:id/accept-follow').post(protect, acceptFollowRequest);
router.route('/:id/reject-follow').post(protect, rejectFollowRequest);

export default router;