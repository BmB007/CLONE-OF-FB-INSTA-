import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { UserPlus } from 'lucide-react';
import PostItem from '../components/posts/PostItem';
import usePostStore from '../store/postStore';
import useAuthStore from '../store/authStore';

const HomePage: React.FC = () => {
  const { posts, getFeedPosts, loading } = usePostStore();
  const { user } = useAuthStore();

  useEffect(() => {
    getFeedPosts();
  }, [getFeedPosts]);

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="max-w-xl mx-auto">
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-pink-500"></div>
          </div>
        ) : posts.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-md p-8 text-center">
            <h2 className="text-2xl font-semibold mb-4">Welcome to Photogram!</h2>
            <p className="text-gray-600 mb-6">
              Your feed is empty. Start following other users to see their posts here.
            </p>
            <Link 
              to={`/profile/${user?._id}`}
              className="px-6 py-2 bg-pink-500 text-white rounded-md inline-flex items-center hover:bg-pink-600 transition-colors"
            >
              <UserPlus className="h-5 w-5 mr-2" />
              Find People to Follow
            </Link>
          </div>
        ) : (
          posts.map((post) => (
            <PostItem key={post._id} post={post} />
          ))
        )}
      </div>
    </div>
  );
};

export default HomePage;