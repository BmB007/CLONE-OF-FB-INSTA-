import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, Camera } from 'lucide-react';
import useAuthStore from '../store/authStore';
import usePostStore from '../store/postStore';

const EditProfilePage: React.FC = () => {
  const { user, updateProfile, loading } = useAuthStore();
  const { uploadImage } = usePostStore();
  const navigate = useNavigate();
  
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [bio, setBio] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [profilePicture, setProfilePicture] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) {
      setUsername(user.username);
      setEmail(user.email || '');
      setBio(user.bio || '');
      setIsPrivate(user.isPrivate);
      setProfilePicture(user.profilePicture);
      setPreviewUrl(user.profilePicture);
    }
  }, [user]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let updatedProfilePicture = profilePicture;
      
      // Upload new profile picture if selected
      if (file) {
        updatedProfilePicture = await uploadImage(file);
      }
      
      // Update profile
      await updateProfile({
        username,
        email,
        bio,
        isPrivate,
        profilePicture: updatedProfilePicture,
      });
      
      // Navigate back to profile
      navigate(`/profile/${user?._id}`);
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white border border-gray-200 rounded-md overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <h1 className="text-xl font-bold text-center">Edit Profile</h1>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="p-6">
              <div className="flex flex-col items-center mb-6">
                <div className="relative mb-4">
                  <img 
                    src={previewUrl || '/default-avatar.png'} 
                    alt={username} 
                    className="w-24 h-24 rounded-full object-cover"
                  />
                  <button 
                    type="button"
                    onClick={triggerFileInput}
                    className="absolute bottom-0 right-0 bg-gray-100 rounded-full p-2 border border-gray-300 hover:bg-gray-200 transition-colors"
                  >
                    <Camera className="h-4 w-4 text-gray-700" />
                  </button>
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                />
                <p className="text-sm text-gray-500">
                  Click on the camera icon to change your profile picture
                </p>
              </div>
              
              <div className="mb-4">
                <label htmlFor="username" className="block text-gray-700 font-medium mb-2">
                  Username
                </label>
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="bio" className="block text-gray-700 font-medium mb-2">
                  Bio
                </label>
                <textarea
                  id="bio"
                  rows={3}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                  placeholder="Tell something about yourself..."
                />
              </div>
              
              <div className="mb-6">
                <div className="flex items-center">
                  <input
                    id="private"
                    type="checkbox"
                    checked={isPrivate}
                    onChange={(e) => setIsPrivate(e.target.checked)}
                    className="h-4 w-4 text-pink-500 focus:ring-pink-500 border-gray-300 rounded"
                  />
                  <label htmlFor="private" className="ml-2 block text-gray-700">
                    Private Account
                  </label>
                </div>
                <p className="mt-1 text-sm text-gray-500 ml-6">
                  When your account is private, only people you approve can see your photos and videos
                </p>
              </div>
            </div>
            
            <div className="p-4 border-t border-gray-200 flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => navigate(`/profile/${user?._id}`)}
                className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2 bg-pink-500 text-white rounded-md hover:bg-pink-600 transition-colors disabled:opacity-70 flex items-center"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                    Saving...
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditProfilePage;