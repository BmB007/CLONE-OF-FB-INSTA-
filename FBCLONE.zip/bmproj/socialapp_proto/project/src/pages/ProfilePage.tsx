import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import ProfileHeader from '../components/profile/ProfileHeader';
import ProfilePosts from '../components/profile/ProfilePosts';
import useUserStore from '../store/userStore';
import useAuthStore from '../store/authStore';

const ProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { profile, getUserProfile, loading } = useUserStore();
  const { user } = useAuthStore();

  useEffect(() => {
    if (id) {
      getUserProfile(id);
    }
  }, [getUserProfile, id]);

  // Show pending follow requests section if viewing own profile and has pending requests
  const hasFollowRequests = 
    profile && 
    user?._id === profile._id && 
    profile.pendingFollowRequests && 
    profile.pendingFollowRequests.length > 0;

  return (
    <div className="container mx-auto px-4 py-6">
      {loading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-pink-500"></div>
        </div>
      ) : profile ? (
        <div className="max-w-4xl mx-auto">
          <ProfileHeader profile={profile} />
          
          {hasFollowRequests && (
            <div className="bg-white border border-gray-200 rounded-md p-4 mb-6">
              <h2 className="font-bold text-lg mb-2">Pending Follow Requests</h2>
              <p className="text-gray-600 mb-4">
                {profile.pendingFollowRequests.length} {profile.pendingFollowRequests.length === 1 ? 'person' : 'people'} requested to follow you
              </p>
              <button className="px-4 py-2 bg-pink-500 text-white rounded-md hover:bg-pink-600 transition-colors">
                Manage Requests
              </button>
            </div>
          )}
          
          <ProfilePosts profile={profile} />
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-600">User not found</p>
        </div>
      )}
    </div>
  );
};

export default ProfilePage;