import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import PostItem from '../components/posts/PostItem';
import usePostStore from '../store/postStore';

const PostPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { currentPost, getPostById, loading, error } = usePostStore();

  useEffect(() => {
    if (id) {
      getPostById(id);
    }
  }, [getPostById, id]);

  // Handle unauthorized or not found
  useEffect(() => {
    if (error) {
      setTimeout(() => {
        navigate('/');
      }, 3000);
    }
  }, [error, navigate]);

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="max-w-2xl mx-auto">
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-pink-500"></div>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md text-center">
            <p>{error}</p>
            <p className="mt-2 text-sm">Redirecting back to home...</p>
          </div>
        ) : currentPost ? (
          <PostItem post={currentPost} showComments={true} />
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-600">Post not found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PostPage;