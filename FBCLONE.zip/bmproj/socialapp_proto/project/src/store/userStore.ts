import { create } from 'zustand';
import { User } from '../types';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import useAuthStore from './authStore';

interface UserState {
  profile: User | null;
  searchResults: User[];
  loading: boolean;
  error: string | null;
}

interface UserStore extends UserState {
  getUserProfile: (id: string) => Promise<void>;
  followUser: (id: string) => Promise<void>;
  unfollowUser: (id: string) => Promise<void>;
  acceptFollowRequest: (id: string) => Promise<void>;
  rejectFollowRequest: (id: string) => Promise<void>;
  searchUsers: (query: string) => Promise<void>;
  clearError: () => void;
}

const API_URL = 'http://localhost:5000/api/users';

const useUserStore = create<UserStore>((set, get) => ({
  profile: null,
  searchResults: [],
  loading: false,
  error: null,

  getUserProfile: async (id) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.get(`${API_URL}/${id}`, config);
      
      set({ profile: data, loading: false });
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to fetch profile';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  followUser: async (id) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post(`${API_URL}/${id}/follow`, {}, config);
      
      // Update the profile if it's loaded
      const currentProfile = get().profile;
      
      if (currentProfile && currentProfile._id === id) {
        set({ 
          profile: { 
            ...currentProfile, 
            isPendingRequest: true 
          },
          loading: false 
        });
      } else {
        set({ loading: false });
      }
      
      toast.success(data.message);
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to follow user';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  unfollowUser: async (id) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post(`${API_URL}/${id}/unfollow`, {}, config);
      
      // Update the profile if it's loaded
      const currentProfile = get().profile;
      
      if (currentProfile && currentProfile._id === id) {
        set({ 
          profile: { 
            ...currentProfile, 
            isFollowing: false 
          },
          loading: false 
        });
      } else {
        set({ loading: false });
      }
      
      toast.success(data.message);
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to unfollow user';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  acceptFollowRequest: async (id) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post(`${API_URL}/${id}/accept-follow`, {}, config);
      
      // Refresh the profile to get updated followers list
      await get().getUserProfile(useAuthStore.getState().user?._id || '');
      
      toast.success(data.message);
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to accept follow request';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  rejectFollowRequest: async (id) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post(`${API_URL}/${id}/reject-follow`, {}, config);
      
      // Refresh the profile to get updated pending requests list
      await get().getUserProfile(useAuthStore.getState().user?._id || '');
      
      toast.success(data.message);
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to reject follow request';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  searchUsers: async (query) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        params: { query },
      };

      const { data } = await axios.get(`${API_URL}/search`, config);
      
      set({ searchResults: data, loading: false });
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to search users';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  clearError: () => set({ error: null }),
}));

export default useUserStore;