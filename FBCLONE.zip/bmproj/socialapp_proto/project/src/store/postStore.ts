import { create } from 'zustand';
import { Post } from '../types';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import useAuthStore from './authStore';

interface PostState {
  posts: Post[];
  currentPost: Post | null;
  loading: boolean;
  error: string | null;
}

interface PostStore extends PostState {
  getFeedPosts: () => Promise<void>;
  getPostById: (id: string) => Promise<void>;
  createPost: (caption: string, image: string) => Promise<void>;
  likePost: (id: string) => Promise<void>;
  addComment: (id: string, text: string) => Promise<void>;
  deletePost: (id: string) => Promise<void>;
  deleteComment: (postId: string, commentId: string) => Promise<void>;
  clearError: () => void;
  uploadImage: (file: File) => Promise<string>;
}

const API_URL = 'http://localhost:5000/api/posts';

const usePostStore = create<PostStore>((set, get) => ({
  posts: [],
  currentPost: null,
  loading: false,
  error: null,

  getFeedPosts: async () => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.get(`${API_URL}/feed`, config);
      
      set({ posts: data, loading: false });
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to fetch posts';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  getPostById: async (id) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.get(`${API_URL}/${id}`, config);
      
      set({ currentPost: data, loading: false });
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to fetch post';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  createPost: async (caption, image) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post(API_URL, { caption, image }, config);
      
      set({ posts: [data, ...get().posts], loading: false });
      toast.success('Post created successfully');
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to create post';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  likePost: async (id) => {
    try {
      const token = useAuthStore.getState().user?.token;
      const userId = useAuthStore.getState().user?._id;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.put(`${API_URL}/${id}/like`, {}, config);
      
      // Update posts
      const updatedPosts = get().posts.map((post) => {
        if (post._id === id) {
          return {
            ...post,
            likes: data.likes,
          };
        }
        return post;
      });

      // Update current post if it exists
      let updatedCurrentPost = get().currentPost;
      if (updatedCurrentPost && updatedCurrentPost._id === id) {
        updatedCurrentPost = {
          ...updatedCurrentPost,
          likes: data.likes,
        };
      }

      set({ 
        posts: updatedPosts,
        currentPost: updatedCurrentPost,
      });
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to like post';
      toast.error(message);
    }
  },

  addComment: async (id, text) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post(`${API_URL}/${id}/comment`, { text }, config);
      
      // Update posts
      const updatedPosts = get().posts.map((post) => {
        if (post._id === id) {
          return data;
        }
        return post;
      });

      set({ 
        posts: updatedPosts,
        currentPost: data,
        loading: false 
      });
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to add comment';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  deletePost: async (id) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      await axios.delete(`${API_URL}/${id}`, config);
      
      set({ 
        posts: get().posts.filter((post) => post._id !== id),
        loading: false 
      });
      
      toast.success('Post deleted successfully');
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to delete post';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  deleteComment: async (postId, commentId) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.delete(`${API_URL}/${postId}/comments/${commentId}`, config);
      
      // Update posts
      const updatedPosts = get().posts.map((post) => {
        if (post._id === postId) {
          return data;
        }
        return post;
      });

      set({ 
        posts: updatedPosts,
        currentPost: data,
        loading: false 
      });
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to delete comment';
      set({ error: message, loading: false });
      toast.error(message);
    }
  },

  uploadImage: async (file) => {
    try {
      set({ loading: true, error: null });

      const token = useAuthStore.getState().user?.token;
      
      const formData = new FormData();
      formData.append('image', file);

      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`,
        },
      };

      const { data } = await axios.post('http://localhost:5000/api/upload', formData, config);
      
      set({ loading: false });
      return data.url;
    } catch (error) {
      const message = error.response?.data?.message || 'Failed to upload image';
      set({ error: message, loading: false });
      toast.error(message);
      throw new Error(message);
    }
  },

  clearError: () => set({ error: null }),
}));

export default usePostStore;