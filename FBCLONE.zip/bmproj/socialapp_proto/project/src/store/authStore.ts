import { create } from 'zustand';
import { AuthState, User } from '../types';
import axios from 'axios';
import { toast } from 'react-hot-toast';

const API_URL = 'http://localhost:5000/api/users';

interface AuthStore extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => Promise<void>;
  clearError: () => void;
}

const useAuthStore = create<AuthStore>((set) => {
  // Initialize user from localStorage if available
  const storedUser = localStorage.getItem('user');
  const initialUser = storedUser ? JSON.parse(storedUser) : null;
  
  return {
    user: initialUser,
    loading: false,
    error: null,
    
    login: async (email, password) => {
      try {
        set({ loading: true, error: null });
        
        const { data } = await axios.post(`${API_URL}/login`, { email, password });
        
        localStorage.setItem('user', JSON.stringify(data));
        set({ user: data, loading: false });
        
        toast.success('Logged in successfully');
      } catch (error) {
        const message = error.response?.data?.message || 'Login failed';
        set({ error: message, loading: false });
        toast.error(message);
      }
    },
    
    register: async (username, email, password) => {
      try {
        set({ loading: true, error: null });
        
        const { data } = await axios.post(API_URL, { username, email, password });
        
        localStorage.setItem('user', JSON.stringify(data));
        set({ user: data, loading: false });
        
        toast.success('Registration successful');
      } catch (error) {
        const message = error.response?.data?.message || 'Registration failed';
        set({ error: message, loading: false });
        toast.error(message);
      }
    },
    
    logout: () => {
      localStorage.removeItem('user');
      set({ user: null });
      toast.success('Logged out successfully');
    },
    
    updateProfile: async (userData) => {
      try {
        set({ loading: true, error: null });
        
        const token = useAuthStore.getState().user?.token;
        
        const config = {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        };
        
        const { data } = await axios.put(`${API_URL}/profile`, userData, config);
        
        localStorage.setItem('user', JSON.stringify(data));
        set({ user: data, loading: false });
        
        toast.success('Profile updated successfully');
      } catch (error) {
        const message = error.response?.data?.message || 'Update failed';
        set({ error: message, loading: false });
        toast.error(message);
      }
    },
    
    clearError: () => set({ error: null }),
  };
});

export default useAuthStore;