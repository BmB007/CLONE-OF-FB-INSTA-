export interface User {
  _id: string;
  username: string;
  email?: string;
  profilePicture: string;
  bio?: string;
  followers?: string[] | number;
  following?: string[] | number;
  posts?: Post[];
  isPrivate: boolean;
  pendingFollowRequests?: string[];
  isAdmin?: boolean;
  isFollowing?: boolean;
  isPendingRequest?: boolean;
  token?: string;
}

export interface Post {
  _id: string;
  user: User;
  caption: string;
  image: string;
  likes: string[];
  comments: Comment[];
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  _id: string;
  user: User;
  text: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
}