import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Home, Search, PlusSquare, User, LogOut } from 'lucide-react';
import useAuthStore from '../../store/authStore';
import useUserStore from '../../store/userStore';

const Header: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { searchUsers, searchResults, loading } = useUserStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);

  const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    
    if (query.trim().length > 0) {
      await searchUsers(query);
      setShowResults(true);
    } else {
      setShowResults(false);
    }
  };

  const handleSelectUser = (userId: string) => {
    setShowResults(false);
    setSearchQuery('');
    navigate(`/profile/${userId}`);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-pink-500">
          Photogram
        </Link>

        {user && (
          <div className="relative w-1/3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search users..."
                className="w-full py-2 px-4 bg-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500"
                value={searchQuery}
                onChange={handleSearch}
                onFocus={() => searchQuery.trim().length > 0 && setShowResults(true)}
              />
              <Search className="absolute right-3 top-2.5 text-gray-400 h-5 w-5" />
            </div>

            {showResults && (
              <div className="absolute w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-y-auto">
                {loading ? (
                  <div className="p-4 text-center text-gray-500">Loading...</div>
                ) : searchResults.length > 0 ? (
                  <ul>
                    {searchResults.map((user) => (
                      <li 
                        key={user._id}
                        className="p-3 hover:bg-gray-50 cursor-pointer flex items-center gap-3"
                        onClick={() => handleSelectUser(user._id)}
                      >
                        <img 
                          src={user.profilePicture} 
                          alt={user.username} 
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div className="flex items-center justify-between w-full">
                          <span className="font-medium">{user.username}</span>
                          {user.isPrivate && (
                            <span className="text-xs text-gray-500">Private</span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="p-4 text-center text-gray-500">No users found</div>
                )}
              </div>
            )}
          </div>
        )}

        <nav>
          {user ? (
            <ul className="flex items-center space-x-6">
              <li>
                <Link to="/" className="text-gray-700 hover:text-pink-500 transition-colors">
                  <Home className="h-6 w-6" />
                </Link>
              </li>
              <li>
                <Link to="/create-post" className="text-gray-700 hover:text-pink-500 transition-colors">
                  <PlusSquare className="h-6 w-6" />
                </Link>
              </li>
              <li>
                <Link to={`/profile/${user._id}`} className="text-gray-700 hover:text-pink-500 transition-colors">
                  <User className="h-6 w-6" />
                </Link>
              </li>
              <li>
                <button 
                  onClick={handleLogout}
                  className="text-gray-700 hover:text-pink-500 transition-colors"
                >
                  <LogOut className="h-6 w-6" />
                </button>
              </li>
            </ul>
          ) : (
            <ul className="flex space-x-4">
              <li>
                <Link 
                  to="/login" 
                  className="px-4 py-2 rounded-md text-white bg-pink-500 hover:bg-pink-600 transition-colors"
                >
                  Login
                </Link>
              </li>
              <li>
                <Link 
                  to="/register" 
                  className="px-4 py-2 rounded-md border border-pink-500 text-pink-500 hover:bg-pink-50 transition-colors"
                >
                  Register
                </Link>
              </li>
            </ul>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;