import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, MessageCircle } from 'lucide-react';
import { Post, User } from '../../types';

interface ProfilePostsProps {
  profile: User;
}

const ProfilePosts: React.FC<ProfilePostsProps> = ({ profile }) => {
  // Check if profile.posts is an array
  const hasPosts = Array.isArray(profile.posts) && profile.posts.length > 0;
  const isPrivateAndNotFollowing = profile.isPrivate && !profile.isFollowing;

  if (isPrivateAndNotFollowing) {
    return (
      <div className="py-8 text-center">
        <div className="max-w-md mx-auto">
          <svg 
            className="w-16 h-16 mx-auto text-gray-400" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={1.5} 
              d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" 
            />
          </svg>
          <h3 className="mt-4 text-xl font-medium text-gray-900">Private Account</h3>
          <p className="mt-2 text-gray-600">
            Follow this account to see their photos and videos.
          </p>
        </div>
      </div>
    );
  }

  if (!hasPosts) {
    return (
      <div className="py-8 text-center">
        <div className="max-w-md mx-auto">
          <svg 
            className="w-16 h-16 mx-auto text-gray-400" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={1.5} 
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" 
            />
          </svg>
          <h3 className="mt-4 text-xl font-medium text-gray-900">No Posts Yet</h3>
          <p className="mt-2 text-gray-600">
            When they share photos, you'll see them here.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {profile.posts.map((post: Post) => (
        <Link 
          key={post._id} 
          to={`/posts/${post._id}`}
          className="relative block aspect-square bg-gray-100 overflow-hidden group"
        >
          <img 
            src={post.image} 
            alt={post.caption} 
            className="w-full h-full object-cover"
          />
          
          <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 flex items-center justify-center space-x-6 transition-opacity">
            <div className="flex items-center text-white">
              <Heart className="h-6 w-6 mr-2 fill-white" />
              <span className="font-semibold">{post.likes.length}</span>
            </div>
            
            <div className="flex items-center text-white">
              <MessageCircle className="h-6 w-6 mr-2" />
              <span className="font-semibold">{post.comments.length}</span>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};

export default ProfilePosts;