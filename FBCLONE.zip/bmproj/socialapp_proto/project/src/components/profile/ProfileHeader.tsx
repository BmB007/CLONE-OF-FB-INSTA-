import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Settings, UserPlus, UserMinus, UserCheck } from 'lucide-react';
import { User } from '../../types';
import useAuthStore from '../../store/authStore';
import useUserStore from '../../store/userStore';

interface ProfileHeaderProps {
  profile: User;
}

const ProfileHeader: React.FC<ProfileHeaderProps> = ({ profile }) => {
  const { user } = useAuthStore();
  const { followUser, unfollowUser } = useUserStore();
  const navigate = useNavigate();

  const isOwnProfile = user?._id === profile._id;
  const isFollowing = profile.isFollowing;
  const isPendingRequest = profile.isPendingRequest;

  const handleFollowToggle = () => {
    if (isFollowing) {
      unfollowUser(profile._id);
    } else if (!isPendingRequest) {
      followUser(profile._id);
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-md p-6 mb-6">
      <div className="flex flex-col md:flex-row items-center">
        <div className="mb-4 md:mb-0 md:mr-10">
          <img 
            src={profile.profilePicture} 
            alt={profile.username} 
            className="w-32 h-32 md:w-40 md:h-40 rounded-full object-cover"
          />
        </div>
        
        <div className="flex-grow text-center md:text-left">
          <div className="flex flex-col md:flex-row items-center mb-4">
            <h1 className="text-2xl font-bold mr-4">{profile.username}</h1>
            
            {isOwnProfile ? (
              <Link 
                to="/profile/edit" 
                className="mt-3 md:mt-0 px-4 py-2 rounded-md border border-gray-300 text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center"
              >
                <Settings className="h-4 w-4 mr-2" />
                Edit Profile
              </Link>
            ) : (
              <button 
                onClick={handleFollowToggle}
                className={`mt-3 md:mt-0 px-4 py-2 rounded-md text-sm font-medium flex items-center ${
                  isFollowing 
                    ? 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                    : isPendingRequest
                      ? 'bg-gray-200 text-gray-700 cursor-default'
                      : 'bg-pink-500 text-white hover:bg-pink-600'
                }`}
                disabled={isPendingRequest}
              >
                {isFollowing ? (
                  <>
                    <UserCheck className="h-4 w-4 mr-2" />
                    Following
                  </>
                ) : isPendingRequest ? (
                  <>
                    <UserCheck className="h-4 w-4 mr-2" />
                    Requested
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Follow
                  </>
                )}
              </button>
            )}
          </div>
          
          <div className="flex justify-center md:justify-start space-x-8 mb-4">
            <div>
              <span className="font-bold">{typeof profile.posts === 'object' ? profile.posts.length : 0}</span> posts
            </div>
            <div>
              <span className="font-bold">{typeof profile.followers === 'object' ? profile.followers.length : profile.followers}</span> followers
            </div>
            <div>
              <span className="font-bold">{typeof profile.following === 'object' ? profile.following.length : profile.following}</span> following
            </div>
          </div>
          
          {profile.bio && (
            <p className="text-gray-800">{profile.bio}</p>
          )}
          
          {profile.isPrivate && !isOwnProfile && !isFollowing && (
            <div className="mt-4 p-4 bg-gray-50 rounded-md text-gray-600 text-center">
              <p>This account is private</p>
              <p className="text-sm">Follow this account to see their photos and videos</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;