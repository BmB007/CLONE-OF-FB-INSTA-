import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, MessageCircle, Send, MoreHorizontal, Trash2 } from 'lucide-react';
import { Post } from '../../types';
import useAuthStore from '../../store/authStore';
import usePostStore from '../../store/postStore';

interface PostItemProps {
  post: Post;
  showComments?: boolean;
}

const PostItem: React.FC<PostItemProps> = ({ post, showComments = false }) => {
  const { user } = useAuthStore();
  const { likePost, addComment, deletePost, deleteComment } = usePostStore();
  const [comment, setComment] = useState('');
  const [showActions, setShowActions] = useState(false);

  const isLiked = post.likes.includes(user?._id || '');
  const isAuthor = post.user._id === user?._id;
  
  const handleLike = () => {
    likePost(post._id);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (comment.trim()) {
      addComment(post._id, comment);
      setComment('');
    }
  };

  const handleDeletePost = () => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      deletePost(post._id);
    }
    setShowActions(false);
  };

  const handleDeleteComment = (commentId: string) => {
    if (window.confirm('Are you sure you want to delete this comment?')) {
      deleteComment(post._id, commentId);
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-md overflow-hidden mb-6">
      {/* Post Header */}
      <div className="flex items-center justify-between p-4">
        <Link to={`/profile/${post.user._id}`} className="flex items-center space-x-3">
          <img 
            src={post.user.profilePicture} 
            alt={post.user.username} 
            className="w-10 h-10 rounded-full object-cover"
          />
          <span className="font-medium">{post.user.username}</span>
        </Link>
        
        {isAuthor && (
          <div className="relative">
            <button 
              onClick={() => setShowActions(!showActions)}
              className="text-gray-500 hover:text-gray-700"
            >
              <MoreHorizontal className="h-5 w-5" />
            </button>
            
            {showActions && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 border border-gray-200">
                <button 
                  onClick={handleDeletePost}
                  className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Post
                </button>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Post Image */}
      <img 
        src={post.image} 
        alt={post.caption} 
        className="w-full object-cover max-h-[600px]"
      />
      
      {/* Post Actions */}
      <div className="p-4 flex space-x-4">
        <button 
          onClick={handleLike}
          className={`flex items-center space-x-1 ${isLiked ? 'text-red-500' : 'text-gray-800'}`}
        >
          <Heart className={`h-6 w-6 ${isLiked ? 'fill-red-500' : ''}`} />
        </button>
        
        <Link to={`/posts/${post._id}`} className="flex items-center space-x-1 text-gray-800">
          <MessageCircle className="h-6 w-6" />
        </Link>
      </div>
      
      {/* Likes */}
      <div className="px-4 pb-2">
        <p className="font-semibold">{post.likes.length} likes</p>
      </div>
      
      {/* Caption */}
      <div className="px-4 pb-2">
        <p>
          <Link to={`/profile/${post.user._id}`} className="font-semibold mr-2">
            {post.user.username}
          </Link>
          {post.caption}
        </p>
      </div>
      
      {/* Comments */}
      {(showComments || post.comments.length > 0) && (
        <div className="px-4 pb-3">
          {!showComments && post.comments.length > 3 ? (
            <>
              <Link to={`/posts/${post._id}`} className="text-gray-500 text-sm">
                View all {post.comments.length} comments
              </Link>
              {post.comments.slice(0, 3).map((comment) => (
                <div key={comment._id} className="flex items-start justify-between mt-2">
                  <p className="text-sm">
                    <Link to={`/profile/${comment.user._id}`} className="font-semibold mr-2">
                      {comment.user.username}
                    </Link>
                    {comment.text}
                  </p>
                  {(comment.user._id === user?._id || post.user._id === user?._id) && (
                    <button 
                      onClick={() => handleDeleteComment(comment._id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </>
          ) : (
            <>
              <h3 className="font-semibold text-gray-800 mb-2">
                {post.comments.length > 0 ? 'Comments' : 'No comments yet'}
              </h3>
              {post.comments.map((comment) => (
                <div key={comment._id} className="flex items-start justify-between mt-2">
                  <p className="text-sm">
                    <Link to={`/profile/${comment.user._id}`} className="font-semibold mr-2">
                      {comment.user.username}
                    </Link>
                    {comment.text}
                  </p>
                  {(comment.user._id === user?._id || post.user._id === user?._id) && (
                    <button 
                      onClick={() => handleDeleteComment(comment._id)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </>
          )}
        </div>
      )}
      
      {/* Add Comment */}
      <div className="px-4 py-3 border-t border-gray-200">
        <form onSubmit={handleAddComment} className="flex">
          <input 
            type="text" 
            placeholder="Add a comment..." 
            className="flex-grow bg-transparent focus:outline-none"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          <button 
            type="submit"
            disabled={!comment.trim()}
            className={`ml-2 ${comment.trim() ? 'text-pink-500' : 'text-gray-300'}`}
          >
            <Send className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default PostItem;